//================================================
// Name          : ProjectTwo.cpp
// Author        : Isaiah Moore
// Version       : 2.0
// Last Update   : July 26, 2026
// Description   : Enhanced CS-300 ABCU Advising Course Planner
//================================================

#include <algorithm>
#include <cctype>
#include <fstream>
#include <iostream>
#include <limits>
#include <memory>
#include <sstream>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <utility>
#include <vector>

using namespace std;

// Structure to hold course details.
struct Course {
    string courseNumber;
    string courseName;
    vector<string> prerequisites;
};

// Stores information about one data-validation problem.
struct ValidationIssue {
    size_t lineNumber = 0;
    string message;
};

// Summarizes what happened while a course file was loaded.
struct LoadSummary {
    bool fileOpened = false;
    size_t linesRead = 0;
    size_t coursesLoaded = 0;
    size_t blankLinesSkipped = 0;
    size_t malformedRecords = 0;
    size_t duplicateRecords = 0;
    size_t missingPrerequisites = 0;
    vector<ValidationIssue> issues;

    bool hasWarnings() const {
        return malformedRecords > 0 || duplicateRecords > 0 ||
            missingPrerequisites > 0;
    }
};

// Remove leading and trailing whitespace from a string.
string trim(const string& value) {
    const auto first = find_if_not(value.begin(), value.end(), [](unsigned char character) {
        return isspace(character) != 0;
    });

    if (first == value.end()) {
        return "";
    }

    const auto last = find_if_not(value.rbegin(), value.rend(), [](unsigned char character) {
        return isspace(character) != 0;
    }).base();

    return string(first, last);
}

// Normalize course numbers so file data and user input are compared consistently.
// Spaces are removed and letters are converted to uppercase.
string normalizeCourseNumber(const string& value) {
    string normalized;

    for (unsigned char character : trim(value)) {
        if (!isspace(character)) {
            normalized.push_back(static_cast<char>(toupper(character)));
        }
    }

    return normalized;
}

// Split a simple comma-separated record while preserving empty trailing fields.
vector<string> splitCsvLine(const string& line) {
    vector<string> fields;
    size_t start = 0;

    while (true) {
        const size_t commaPosition = line.find(',', start);

        if (commaPosition == string::npos) {
            fields.push_back(line.substr(start));
            break;
        }

        fields.push_back(line.substr(start, commaPosition - start));
        start = commaPosition + 1;
    }

    return fields;
}

// Course numbers must contain only letters and digits and must include both.
bool isValidCourseNumber(const string& courseNumber) {
    if (courseNumber.empty()) {
        return false;
    }

    bool containsLetter = false;
    bool containsDigit = false;

    for (unsigned char character : courseNumber) {
        if (!isalnum(character)) {
            return false;
        }

        containsLetter = containsLetter || (isalpha(character) != 0);
        containsDigit = containsDigit || (isdigit(character) != 0);
    }

    return containsLetter && containsDigit;
}

// Node structure for the binary search tree.
struct TreeNode {
    Course course;
    unique_ptr<TreeNode> left;
    unique_ptr<TreeNode> right;

    explicit TreeNode(const Course& courseValue) : course(courseValue) {}
};

// A hybrid course catalog that uses:
//   1. A BST for ordered course output.
//   2. An unordered_map for average O(1) lookup and validation.
class CourseCatalog {
private:
    unique_ptr<TreeNode> root;
    unordered_map<string, Course> courseLookup;

    static void insertNode(unique_ptr<TreeNode>& node, const Course& course) {
        if (!node) {
            node = make_unique<TreeNode>(course);
            return;
        }

        if (course.courseNumber < node->course.courseNumber) {
            insertNode(node->left, course);
        }
        else {
            insertNode(node->right, course);
        }
    }

    static void printInOrder(const unique_ptr<TreeNode>& node) {
        if (!node) {
            return;
        }

        printInOrder(node->left);
        cout << node->course.courseNumber << ": " << node->course.courseName << '\n';
        printInOrder(node->right);
    }

    static void collectInOrder(
        const unique_ptr<TreeNode>& node,
        vector<string>& courseNumbers) {

        if (!node) {
            return;
        }

        collectInOrder(node->left, courseNumbers);
        courseNumbers.push_back(node->course.courseNumber);
        collectInOrder(node->right, courseNumbers);
    }

    void validatePrerequisites(LoadSummary& summary) const {
        for (const auto& entry : courseLookup) {
            const Course& course = entry.second;

            for (const string& prerequisite : course.prerequisites) {
                if (courseLookup.find(prerequisite) == courseLookup.end()) {
                    ++summary.missingPrerequisites;
                    summary.issues.push_back({
                        0,
                        course.courseNumber + " references missing prerequisite " + prerequisite
                    });
                }
            }
        }
    }

public:
    CourseCatalog() = default;
    ~CourseCatalog() = default;

    // Prevent accidental shallow copies. Moving remains safe because ownership
    // is handled by unique_ptr and standard containers.
    CourseCatalog(const CourseCatalog&) = delete;
    CourseCatalog& operator=(const CourseCatalog&) = delete;
    CourseCatalog(CourseCatalog&&) noexcept = default;
    CourseCatalog& operator=(CourseCatalog&&) noexcept = default;

    void clear() {
        root.reset();
        courseLookup.clear();
    }

    bool empty() const {
        return courseLookup.empty();
    }

    size_t size() const {
        return courseLookup.size();
    }

    // Load and validate course records from any input stream. This design makes
    // the parser easier to test without depending on external files.
    LoadSummary loadFromStream(istream& input) {
        clear();

        LoadSummary summary;
        summary.fileOpened = true;
        string line;
        size_t lineNumber = 0;

        while (getline(input, line)) {
            ++lineNumber;
            ++summary.linesRead;

            if (trim(line).empty()) {
                ++summary.blankLinesSkipped;
                continue;
            }

            vector<string> fields = splitCsvLine(line);
            for (string& field : fields) {
                field = trim(field);
            }

            if (fields.size() < 2 || fields[0].empty() || fields[1].empty()) {
                ++summary.malformedRecords;
                summary.issues.push_back({
                    lineNumber,
                    "Record must include a course number and course name."
                });
                continue;
            }

            Course course;
            course.courseNumber = normalizeCourseNumber(fields[0]);
            course.courseName = fields[1];

            if (!isValidCourseNumber(course.courseNumber)) {
                ++summary.malformedRecords;
                summary.issues.push_back({
                    lineNumber,
                    "Invalid course number: " + fields[0]
                });
                continue;
            }

            if (courseLookup.find(course.courseNumber) != courseLookup.end()) {
                ++summary.duplicateRecords;
                summary.issues.push_back({
                    lineNumber,
                    "Duplicate course number ignored: " + course.courseNumber
                });
                continue;
            }

            unordered_set<string> uniquePrerequisites;
            for (size_t index = 2; index < fields.size(); ++index) {
                const string prerequisite = normalizeCourseNumber(fields[index]);

                // Empty fields caused by trailing commas are ignored.
                if (prerequisite.empty()) {
                    continue;
                }

                if (!isValidCourseNumber(prerequisite)) {
                    ++summary.malformedRecords;
                    summary.issues.push_back({
                        lineNumber,
                        "Invalid prerequisite ignored: " + fields[index]
                    });
                    continue;
                }

                if (prerequisite == course.courseNumber) {
                    ++summary.malformedRecords;
                    summary.issues.push_back({
                        lineNumber,
                        "A course cannot list itself as a prerequisite: " + prerequisite
                    });
                    continue;
                }

                if (uniquePrerequisites.insert(prerequisite).second) {
                    course.prerequisites.push_back(prerequisite);
                }
            }

            courseLookup.emplace(course.courseNumber, course);
            insertNode(root, course);
        }

        summary.coursesLoaded = courseLookup.size();
        validatePrerequisites(summary);
        return summary;
    }

    LoadSummary loadFromFile(const string& fileName) {
        ifstream file(fileName);

        if (!file.is_open()) {
            LoadSummary summary;
            summary.issues.push_back({0, "Unable to open file: " + fileName});
            return summary;
        }

        return loadFromStream(file);
    }

    // Hash-map search: average O(1), worst-case O(n).
    const Course* findCourse(const string& courseNumber) const {
        const string normalizedNumber = normalizeCourseNumber(courseNumber);
        const auto courseIterator = courseLookup.find(normalizedNumber);

        if (courseIterator == courseLookup.end()) {
            return nullptr;
        }

        return &courseIterator->second;
    }

    void printCourseList() const {
        if (empty()) {
            cout << "No course data is loaded.\n";
            return;
        }

        cout << "\nABCU Course List\n";
        cout << "================\n";
        printInOrder(root);
    }

    void displayCourse(const string& courseNumber) const {
        const Course* course = findCourse(courseNumber);

        if (!course) {
            cout << "Course not found.\n";
            return;
        }

        cout << "\nCourse Number: " << course->courseNumber << '\n';
        cout << "Course Name: " << course->courseName << '\n';

        if (course->prerequisites.empty()) {
            cout << "Prerequisites: None\n";
            return;
        }

        cout << "Prerequisites:\n";
        for (const string& prerequisiteNumber : course->prerequisites) {
            const Course* prerequisite = findCourse(prerequisiteNumber);

            if (prerequisite) {
                cout << "  - " << prerequisite->courseNumber
                    << ": " << prerequisite->courseName << '\n';
            }
            else {
                cout << "  - " << prerequisiteNumber
                    << ": Course not found in loaded data\n";
            }
        }
    }

    vector<string> getOrderedCourseNumbers() const {
        vector<string> courseNumbers;
        collectInOrder(root, courseNumbers);
        return courseNumbers;
    }
};

void printLoadSummary(const LoadSummary& summary) {
    cout << "\nLoad and Validation Summary\n";
    cout << "===========================\n";

    if (!summary.fileOpened) {
        cout << "Status: File could not be opened.\n";
    }
    else {
        cout << "Status: File processed.\n";
    }

    cout << "Lines read: " << summary.linesRead << '\n';
    cout << "Courses loaded: " << summary.coursesLoaded << '\n';
    cout << "Blank lines skipped: " << summary.blankLinesSkipped << '\n';
    cout << "Malformed records or fields: " << summary.malformedRecords << '\n';
    cout << "Duplicate course records: " << summary.duplicateRecords << '\n';
    cout << "Missing prerequisite references: " << summary.missingPrerequisites << '\n';

    if (summary.issues.empty()) {
        cout << "Validation result: No issues found.\n";
        return;
    }

    cout << "\nValidation details:\n";
    for (const ValidationIssue& issue : summary.issues) {
        if (issue.lineNumber > 0) {
            cout << "  - Line " << issue.lineNumber << ": " << issue.message << '\n';
        }
        else {
            cout << "  - " << issue.message << '\n';
        }
    }
}

class TestRunner {
private:
    int passed = 0;
    int failed = 0;

public:
    void check(bool condition, const string& testName) {
        if (condition) {
            ++passed;
            cout << "[PASS] " << testName << '\n';
        }
        else {
            ++failed;
            cout << "[FAIL] " << testName << '\n';
        }
    }

    int finish() const {
        cout << "\nSelf-test results: " << passed << " passed, "
            << failed << " failed.\n";
        return failed;
    }
};

int runSelfTests() {
    cout << "\nRunning Course Planner Self-Tests\n";
    cout << "=================================\n";

    TestRunner tests;

    {
        istringstream input(
            "MATH201,Discrete Mathematics\n"
            "CSCI200,Data Structures,CSCI101\n"
            "CSCI101,Introduction to Programming in C++,CSCI100\n"
            "CSCI100,Introduction to Computer Science\n");

        CourseCatalog catalog;
        const LoadSummary summary = catalog.loadFromStream(input);

        tests.check(summary.coursesLoaded == 4, "Loads all valid course records");
        tests.check(summary.malformedRecords == 0, "Valid data has no malformed records");
        tests.check(summary.missingPrerequisites == 0, "Valid prerequisites resolve correctly");
        tests.check(catalog.findCourse(" csci 200 ") != nullptr,
            "Search normalizes case and whitespace");
        tests.check(
            catalog.getOrderedCourseNumbers() ==
            vector<string>({"CSCI100", "CSCI101", "CSCI200", "MATH201"}),
            "BST traversal returns alphanumeric order");
    }

    {
        istringstream input(
            "CSCI100,Introduction to Computer Science,,\n"
            "INVALID_ONLY_ONE_FIELD\n"
            ",Missing Course Number\n"
            "CSCI200,\n");

        CourseCatalog catalog;
        const LoadSummary summary = catalog.loadFromStream(input);

        tests.check(summary.coursesLoaded == 1, "Rejects records missing required fields");
        tests.check(summary.malformedRecords == 3, "Counts malformed records accurately");
        const Course* course = catalog.findCourse("CSCI100");
        tests.check(
            course != nullptr && course->prerequisites.empty(),
            "Ignores empty prerequisites created by trailing commas");
    }

    {
        istringstream input(
            "CSCI100,First Course Name\n"
            "csci100,Duplicate Course Name\n");

        CourseCatalog catalog;
        const LoadSummary summary = catalog.loadFromStream(input);
        const Course* course = catalog.findCourse("CSCI100");

        tests.check(summary.duplicateRecords == 1, "Detects duplicate course numbers");
        tests.check(course != nullptr && course->courseName == "First Course Name",
            "Keeps the first valid duplicate record");
    }

    {
        istringstream input(
            "CSCI300,Algorithms,CSCI200\n"
            "MATH201,Discrete Mathematics\n");

        CourseCatalog catalog;
        const LoadSummary summary = catalog.loadFromStream(input);

        tests.check(summary.missingPrerequisites == 1,
            "Reports prerequisites that do not exist in the catalog");
    }

    {
        istringstream input(
            "CSCI100,Introduction to Computer Science\n"
            "\n"
            "   \n");

        CourseCatalog catalog;
        const LoadSummary summary = catalog.loadFromStream(input);

        tests.check(summary.blankLinesSkipped == 2, "Skips and counts blank lines");
    }

    {
        istringstream input("");
        CourseCatalog catalog;
        const LoadSummary summary = catalog.loadFromStream(input);

        tests.check(
            summary.coursesLoaded == 0 && catalog.empty() &&
            catalog.findCourse("CSCI100") == nullptr,
            "Handles an empty data source safely");
    }

    return tests.finish();
}

int main(int argc, char* argv[]) {
    if (argc > 1 && string(argv[1]) == "--self-test") {
        return runSelfTests() == 0 ? 0 : 1;
    }

    CourseCatalog courseCatalog;

    while (true) {
        cout << "\nWhat would you like to do?\n\n"
            << "1. Load Course Data\n"
            << "2. Print Course List\n"
            << "3. Search Course\n"
            << "4. Run Self-Tests\n"
            << "9. Exit\n"
            << "Enter choice: ";

        int choice;
        if (!(cin >> choice)) {
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout << "Invalid input. Please enter a number.\n";
            continue;
        }

        cin.ignore(numeric_limits<streamsize>::max(), '\n');

        switch (choice) {
        case 1: {
            cout << "Enter file name: ";
            string fileName;
            getline(cin, fileName);
            fileName = trim(fileName);

            CourseCatalog loadedCatalog;
            const LoadSummary summary = loadedCatalog.loadFromFile(fileName);
            printLoadSummary(summary);

            if (summary.fileOpened) {
                courseCatalog = move(loadedCatalog);
            }
            else {
                cout << "The currently loaded catalog was not changed.\n";
            }
            break;
        }
        case 2:
            courseCatalog.printCourseList();
            break;
        case 3: {
            cout << "Enter course number: ";
            string courseNumber;
            getline(cin, courseNumber);
            courseCatalog.displayCourse(courseNumber);
            break;
        }
        case 4:
            runSelfTests();
            break;
        case 9:
            cout << "Exiting program... Thank you for using the course planner!\n";
            return 0;
        default:
            cout << "Invalid choice. Please select 1, 2, 3, 4, or 9.\n";
        }
    }
}
