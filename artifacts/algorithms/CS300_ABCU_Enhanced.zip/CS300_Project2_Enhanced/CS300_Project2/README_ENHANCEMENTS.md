# CS-300 ABCU Advising Course Planner — Enhanced Version

## Purpose

This version enhances the original ABCU course planner for the CS-499 Algorithms and Data Structures artifact. It preserves the binary search tree used to print courses in alphanumeric order while adding a hash-based lookup structure, stronger validation, safer memory management, and repeatable tests.

## Main Enhancements

- **Hybrid data structures:** A binary search tree supports ordered output, while an `unordered_map` supports direct course lookup, duplicate detection, and prerequisite validation.
- **Safer ownership:** BST nodes use `std::unique_ptr`, eliminating the original raw-pointer memory leak and preventing unsafe shallow copies.
- **Normalized input:** Course numbers are trimmed, converted to uppercase, and stripped of spaces before storage or lookup.
- **Improved file parsing:** The loader validates required fields, ignores empty trailing prerequisite fields, rejects invalid course numbers, and keeps valid records even when other lines contain errors.
- **Duplicate detection:** Repeated course numbers are reported and ignored so that the first valid record remains authoritative.
- **Prerequisite validation:** Every prerequisite is checked after loading, allowing references to courses that appear later in the file while still reporting missing courses.
- **Validation summary:** The program reports lines read, courses loaded, blank lines, malformed records, duplicates, and missing prerequisites.
- **Built-in tests:** Thirteen self-tests cover valid loading, malformed records, trailing commas, duplicates, missing prerequisites, normalized search, blank lines, and ordered BST traversal.

## Algorithm and Data-Structure Analysis

| Operation | Structure | Expected Complexity |
|---|---|---|
| Direct course search | `unordered_map` | Average O(1), worst O(n) |
| Duplicate detection | `unordered_map` | Average O(1) per record |
| Prerequisite validation | `unordered_map` | Average O(1) per prerequisite |
| BST insertion | Binary search tree | Average O(log n), worst O(n) |
| Ordered course output | In-order BST traversal | O(n) |

The BST is intentionally retained because its in-order traversal naturally produces alphanumeric output. The hash map addresses the original BST-only design's less predictable direct-search performance.

## Running the Program

1. Open `CS300_Project2.sln` in Visual Studio 2022.
2. Build the project using Debug or Release and x64 or x86.
3. Run the program.
4. Choose **1** and load `courses.txt` or `CS 300 ABCU_Advising_Program_Input.csv`.
5. Use **2** to print the ordered list and **3** to search for a course.
6. Use **4** to run the built-in self-tests.

The project is configured to use the C++17 language standard.

## Validation Demonstration

Load `test_courses_invalid.txt` to demonstrate the enhanced validation. The expected summary is:

- 8 lines read
- 4 courses loaded
- 3 malformed records
- 1 duplicate course record
- 1 missing prerequisite reference

## Test Execution

The tests can also be run from a terminal with:

```text
CS300_Project2.exe --self-test
```

A successful run reports:

```text
Self-test results: 13 passed, 0 failed.
```
