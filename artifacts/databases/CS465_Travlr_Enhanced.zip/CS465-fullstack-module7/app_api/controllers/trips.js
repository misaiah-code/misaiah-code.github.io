const Trip = require('../models/travlr');

/**
 * Return a consistent API response for database and validation errors.
 *
 * @param {object} res Express response object
 * @param {Error} error Error returned by Mongoose or MongoDB
 * @returns {object} Express response
 */
const handleDatabaseError = (res, error) => {
    console.error('Trip database operation failed:', {
        name: error.name,
        code: error.code,
        message: error.message
    });

    if (error.name === 'ValidationError') {
        return res.status(400).json({
            message: 'Trip validation failed.',
            details: Object.values(error.errors).map((item) => item.message)
        });
    }

    if (error.name === 'CastError') {
        return res.status(400).json({
            message: `The value supplied for ${error.path} is invalid.`
        });
    }

    if (error.code === 11000) {
        return res.status(409).json({
            message: 'A trip with that code already exists.'
        });
    }

    return res.status(500).json({
        message: 'An unexpected database error occurred.'
    });
};

// GET: /trips - Return every trip.
const tripsList = async (req, res) => {
    try {
        const trips = await Trip.find({}).exec();
        return res.status(200).json(trips);
    } catch (error) {
        return handleDatabaseError(res, error);
    }
};

// GET: /trips/:tripCode - Return one trip identified by its code.
const tripsFindByCode = async (req, res) => {
    try {
        const trip = await Trip.findOne({
            code: req.params.tripCode
        }).exec();

        if (!trip) {
            return res.status(404).json({
                message: 'Trip not found.'
            });
        }

        return res.status(200).json(trip);
    } catch (error) {
        return handleDatabaseError(res, error);
    }
};

// POST: /trips - Create a new trip.
const tripsAddTrip = async (req, res) => {
    try {
        const trip = await Trip.create({
            code: req.body.code,
            name: req.body.name,
            length: req.body.length,
            start: req.body.start,
            resort: req.body.resort,
            perPerson: req.body.perPerson,
            image: req.body.image,
            description: req.body.description
        });

        return res.status(201).json(trip);
    } catch (error) {
        return handleDatabaseError(res, error);
    }
};

// PUT: /trips/:tripCode - Update an existing trip.
const tripsUpdateTrip = async (req, res) => {
    try {
        const trip = await Trip.findOneAndUpdate(
            { code: req.params.tripCode },
            {
                code: req.body.code,
                name: req.body.name,
                length: req.body.length,
                start: req.body.start,
                resort: req.body.resort,
                perPerson: req.body.perPerson,
                image: req.body.image,
                description: req.body.description
            },
            {
                new: true,
                runValidators: true
            }
        ).exec();

        if (!trip) {
            return res.status(404).json({
                message: 'Trip not found.'
            });
        }

        return res.status(200).json(trip);
    } catch (error) {
        return handleDatabaseError(res, error);
    }
};

// DELETE: /trips/:tripCode - Delete an existing trip.
const tripsDeleteTrip = async (req, res) => {
    try {
        const trip = await Trip.findOneAndDelete({
            code: req.params.tripCode
        }).exec();

        if (!trip) {
            return res.status(404).json({
                message: 'Trip not found.'
            });
        }

        return res.sendStatus(204);
    } catch (error) {
        return handleDatabaseError(res, error);
    }
};

module.exports = {
    tripsList,
    tripsFindByCode,
    tripsAddTrip,
    tripsUpdateTrip,
    tripsDeleteTrip
};
