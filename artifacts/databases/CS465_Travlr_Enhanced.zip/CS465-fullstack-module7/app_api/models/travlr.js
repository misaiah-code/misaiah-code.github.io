const mongoose = require('mongoose');

// Define the trip schema and enforce data-quality rules at the database layer.
const tripSchema = new mongoose.Schema({
    code: {
        type: String,
        required: [true, 'Trip code is required.'],
        unique: true,
        trim: true,
        minlength: [3, 'Trip code must contain at least 3 characters.'],
        maxlength: [10, 'Trip code cannot exceed 10 characters.'],
        match: [
            /^[A-Z0-9]+$/,
            'Trip code may contain only uppercase letters and numbers.'
        ],
        index: true
    },
    name: {
        type: String,
        required: [true, 'Trip name is required.'],
        trim: true,
        maxlength: [100, 'Trip name cannot exceed 100 characters.'],
        index: true
    },
    length: {
        type: String,
        required: [true, 'Trip length is required.'],
        trim: true
    },
    start: {
        type: Date,
        required: [true, 'Start date is required.']
    },
    resort: {
        type: String,
        required: [true, 'Resort is required.'],
        trim: true,
        maxlength: [100, 'Resort name cannot exceed 100 characters.']
    },
    perPerson: {
        type: String,
        required: [true, 'Price is required.'],
        trim: true,
        validate: {
            validator: (value) => {
                const price = Number(value);
                return Number.isFinite(price) && price >= 0;
            },
            message: 'Price must be a nonnegative number.'
        }
    },
    image: {
        type: String,
        required: [true, 'Image path is required.'],
        trim: true
    },
    description: {
        type: String,
        required: [true, 'Description is required.'],
        trim: true,
        maxlength: [1000, 'Description cannot exceed 1,000 characters.']
    }
});

module.exports = mongoose.model('trips', tripSchema);
