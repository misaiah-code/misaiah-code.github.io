const express = require('express');
const jwt = require('jsonwebtoken');

const tripsController = require('../controllers/trips');
const authController = require('../controllers/authentication');

const router = express.Router();

// Verify that protected requests contain a valid JSON Web Token.
const authenticateJWT = (req, res, next) => {
    const authHeader = req.headers.authorization;

    if (!authHeader || !authHeader.startsWith('Bearer ')) {
        return res.status(401).json({
            message: 'A Bearer token is required.'
        });
    }

    const token = authHeader.split(' ')[1];

    return jwt.verify(token, process.env.JWT_SECRET, (error, verifiedToken) => {
        if (error) {
            return res.status(401).json({
                message: 'The authentication token is invalid or expired.'
            });
        }

        req.auth = verifiedToken;
        return next();
    });
};

router.route('/register').post(authController.register);
router.route('/login').post(authController.login);

router
    .route('/trips')
    .get(tripsController.tripsList)
    .post(authenticateJWT, tripsController.tripsAddTrip);

router
    .route('/trips/:tripCode')
    .get(tripsController.tripsFindByCode)
    .put(authenticateJWT, tripsController.tripsUpdateTrip)
    .delete(authenticateJWT, tripsController.tripsDeleteTrip);

module.exports = router;
